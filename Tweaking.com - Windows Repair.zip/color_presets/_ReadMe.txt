This folder stores the saved color preset ini files.

If you have a color preset you think others would like then just email me the
ini file and I will add it to the programs for others to use :-)

The color preset name is the name of the file (Please no Unicode characters only ANSI). 
So if you send me a preset that is already named the same as another I will change the name slightly.

You are also welcome to post your preset color ini file along with a screen shot in the Tweaking.com
forums for others to download and use.

-Shane
shane@tweaking.com
